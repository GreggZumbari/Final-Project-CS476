//
// Copyright (C) 2013 OpenSim Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later
//


#include "inet/applications/base/ApplicationBase.h"

namespace inet {

ApplicationBase::ApplicationBase()
{
}

} // namespace inet

