//
// Copyright (C) 2004 OpenSim Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later
//


#include "inet/common/INETDefs.h"

namespace inet {

OPP_THREAD_LOCAL int evFlags = 1;

} // namespace inet

