//
// Copyright (C) 2013 OpenSim Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later
//


#include "inet/common/geometry/base/GeometricObjectBase.h"

namespace inet {

} // namespace inet

