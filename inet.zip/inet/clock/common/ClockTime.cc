//
// Copyright (C) 2020 OpenSim Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later
//


#include "inet/clock/common/ClockTime.h"

namespace inet {

const ClockTime ClockTime::ZERO;

} // namespace inet

